package core.com.file.management.model;

import java.util.Date;

import lombok.Data;

@Data
public class BulkUploadFileRest {
	
	private String imCode;
	private String id;
	private String guid;
	private String name;
	private String content;
	private String status;
	private String type;
	private Date created;
	private Date updated;
	
}
