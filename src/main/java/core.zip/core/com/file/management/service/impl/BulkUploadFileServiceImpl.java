package core.com.file.management.service.impl;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.dozer.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import core.com.file.management.common.ErrorCode;
import core.com.file.management.common.FileManagementConstant;
import core.com.file.management.entity.BulkUploadFileEntity;
import core.com.file.management.exception.FileConfigurationException;
import core.com.file.management.model.BulkUploadFileResponse;
import core.com.file.management.model.BulkUploadFileRest;
import core.com.file.management.model.ResponseMetadata;
import core.com.file.management.repo.BulkUploadFileRepo;
import core.com.file.management.service.BulkUploadFileService;
import core.com.file.management.util.FileManagementUtil;
import core.com.file.management.validation.BulkUploadValidator;

@Service
public class BulkUploadFileServiceImpl implements BulkUploadFileService {

	@Autowired
	private FileManagementUtil fileManagementUtil;
	
	@Autowired
	private BulkUploadValidator bulkUploadValidator;

	@Autowired
	private BulkUploadFileRepo bulkUploadFileRepo;

	@Autowired
	private Mapper mapper;

	@Override
	public String upload(MultipartFile file) throws FileConfigurationException {

//		HSSFWorkbook workbook = null;
//		FileOutputStream fileOutputStream = null;
		try {
			if(file.isEmpty()) {
				throw new FileConfigurationException(ErrorCode.EMPTY_FILE_CONTENT);
			}
			
			List<String> contentList = Arrays.asList(new String(file.getInputStream().readAllBytes()).split(FileManagementConstant.LINE_DELIMITER));
			
			
			
			
			
			/*String contentHash = fileManagementUtil.getContentHash(uploadFileRest.getContent());
			String filePath = fileManagementUtil.getFilePath(contentHash, uploadFileRest.getName(),
					uploadFileRest.getType());
			fileOutputStream = new FileOutputStream(filePath);
			String decodedString = new String(Base64.getDecoder().decode(uploadFileRest.getContent()));
			//bulkUploadValidator.validateUploadedFileContent(decodedString);
			if (FileManagementConstant.XLS_FILE.equals(uploadFileRest.getType())) {
				workbook = createExcelWorkbook(decodedString);
				workbook.write(fileOutputStream);
			} else {
				fileOutputStream.write(decodedString.getBytes());
			}
			BulkUploadFileEntity bulkUploadFileEntity = mapper.map(uploadFileRest, BulkUploadFileEntity.class);
			bulkUploadFileEntity.setHash(contentHash);
			String bulkFileGuid = fileManagementUtil.getGuid(FileManagementConstant.BULK_UPLOAD);
			bulkUploadFileEntity.setGuid(bulkFileGuid);
			bulkUploadFileEntity.setCreated(new Date());
			bulkUploadFileEntity.setUpdated(new Date());
			bulkUploadFileRepo.save(bulkUploadFileEntity);

		} catch (NoSuchAlgorithmException e) {
			throw new FileConfigurationException(ErrorCode.FILE_PROCESSING_ERROR);*/
		} catch (Exception e) {
			throw new FileConfigurationException(ErrorCode.FILE_PROCESSING_ERROR);
		} /*finally {
			try {
				workbook.close();
				fileOutputStream.close();
			} catch (IOException e) {
				throw new FileConfigurationException(ErrorCode.FILE_PROCESSING_ERROR);
			}

		}*/
		return FileManagementConstant.FILE_UPLOADED_SUCCESS;
	}

	@Override
	public BulkUploadFileResponse getUploadFileDetails(Pageable pageable, String status, String imCode) {

		/*
		 * long totalCount = bulkUploadFileRepo.count(); long totalPages = totalCount /
		 * pageable.getPageSize();
		 */
		Page<BulkUploadFileEntity> bulkUploadPage = null;
		if (status == null) {
			bulkUploadPage = bulkUploadFileRepo.findAll(pageable);
		} else {
			bulkUploadPage = bulkUploadFileRepo.findByStatusAndImCode(imCode, status, pageable);
		}

		List<BulkUploadFileRest> uploadFileRestList = bulkUploadPage.getContent().stream()
				.map(bup -> mapper.map(bup, BulkUploadFileRest.class)).collect(Collectors.toList());

		ResponseMetadata metadata = new ResponseMetadata();
		metadata.setElements(bulkUploadPage.getTotalElements());
		metadata.setTotalPages(bulkUploadPage.getTotalPages());
		metadata.setSize(bulkUploadPage.getSize());
		metadata.setPage(bulkUploadPage.getNumber());
		BulkUploadFileResponse uploadFileResponse = new BulkUploadFileResponse();
		uploadFileResponse.setMetadata(metadata);
		uploadFileResponse.setData(uploadFileRestList);

		return uploadFileResponse;
	}

	@Override
	public BulkUploadFileRest getUploadFileById(String id) throws FileConfigurationException {

		FileInputStream fileInputStream = null;
		BulkUploadFileEntity uploadFileEntity = bulkUploadFileRepo.getById(id);
		BulkUploadFileRest uploadFileRest = mapper.map(uploadFileEntity, BulkUploadFileRest.class);
		if (FileManagementConstant.XLS_FILE.equals(uploadFileRest.getType())) {
			String filePath = fileManagementUtil.getFilePath(uploadFileEntity.getHash(), uploadFileRest.getName(),
					uploadFileRest.getType());
			try {
				fileInputStream = new FileInputStream(filePath);
				String content = readFromExcelWorkbook(fileInputStream);
				uploadFileRest.setContent(content);
			} catch (FileNotFoundException e) {
				throw new FileConfigurationException(ErrorCode.FILE_PROCESSING_ERROR);
			} catch (IOException e) {
				throw new FileConfigurationException(ErrorCode.FILE_PROCESSING_ERROR);
			} finally {
				try {
					fileInputStream.close();
				} catch (IOException e) {
					throw new FileConfigurationException(ErrorCode.FILE_PROCESSING_ERROR);
				}
			}
		}

		return uploadFileRest;
	}

	private HSSFWorkbook createExcelWorkbook(String uploadDecodedContent) {
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet();
		List<String> contentList = Arrays.asList(uploadDecodedContent.split(FileManagementConstant.LINE_DELIMITER));
		int rowNum = 0;
		contentList.forEach(cl -> {
			HSSFRow row = sheet.createRow(Math.abs(~rowNum)); // increment without addition since addition is blocked
			List<String> clList = Arrays.asList(cl.split(FileManagementConstant.COMMA));
			int cellNum = 0;
			clList.forEach(cll -> {
				HSSFCell cell = row.createCell(Math.abs(~cellNum));
				cell.setCellValue((String) cll);
			});
		});
		return workbook;
	}

	private String readFromExcelWorkbook(FileInputStream fileInputStream) throws IOException {
		HSSFWorkbook workbook = new HSSFWorkbook(fileInputStream);
		HSSFSheet sheet = workbook.getSheetAt(0);
		Iterator<?> rowIterator = sheet.rowIterator();
		StringBuffer sb = new StringBuffer();
		while (rowIterator.hasNext()) {
			HSSFRow row = (HSSFRow) rowIterator.next();
			StringBuffer sbInside = new StringBuffer();
			for (int cellIndex = row.getFirstCellNum(); cellIndex < row.getLastCellNum(); cellIndex++) {
				HSSFCell cell = row.getCell(cellIndex, HSSFRow.MissingCellPolicy.CREATE_NULL_AS_BLANK);
				sbInside.append(cell.getStringCellValue());
				sbInside.append(FileManagementConstant.COMMA);
			}
			if (row.getRowNum() == 0) {
				sb.append(sbInside.toString());
			} else {
				sb.append(FileManagementConstant.LINE_DELIMITER);
				sb.append(sbInside.toString());
			}
		}
		workbook.close();
		return sb.toString();
	}

}
