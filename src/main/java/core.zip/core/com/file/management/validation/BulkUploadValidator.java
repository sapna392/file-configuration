package core.com.file.management.validation;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;

import core.com.file.management.common.ErrorCode;
import core.com.file.management.common.FileManagementConstant;
import core.com.file.management.model.BulkUploadFileRest;

@Component
@Deprecated
public class BulkUploadValidator {

	@Value("${com.sbi.scfu.max.file.size}")
	private Integer MAX_FILE_SIZE;

	public void validate(Object target, Errors errors) {

		BulkUploadFileRest uploadFileDetails = (BulkUploadFileRest) target;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", ErrorCode.EMPTY_FILE_NAME, "Invalid file");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "content", ErrorCode.EMPTY_FILE_CONTENT, "Invalid file");
		if (!FileManagementConstant.FILE_TYPE.contains(uploadFileDetails.getType())) {
			errors.rejectValue("type", ErrorCode.INVALID_FILE_TYPE, "Invalid file");
		}

		byte[] content_byte = uploadFileDetails.getContent().getBytes();
		if (content_byte.length > MAX_FILE_SIZE) {
			errors.rejectValue("content", ErrorCode.FILE_SIZE_EXCEEDED, "Invalid file");
		}

	}
	
	public void validateUploadedFileContent(String content) {
		
	}

}
