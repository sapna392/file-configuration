package core.com.file.management.service;

import org.springframework.data.domain.Pageable;
import org.springframework.web.multipart.MultipartFile;

import core.com.file.management.exception.FileConfigurationException;
import core.com.file.management.model.BulkUploadFileResponse;
import core.com.file.management.model.BulkUploadFileRest;

public interface BulkUploadFileService {

	public String upload(MultipartFile file) throws FileConfigurationException;

	public BulkUploadFileResponse getUploadFileDetails(Pageable pageable, String status, String imCode);

	public BulkUploadFileRest getUploadFileById(String id) throws FileConfigurationException;

}
